<?php
//создаём массив содержащий переменные настройки работы с базой данных

$config["mysql"]["host"] = "localhost"; // доменное имя 
$config["mysql"]["user"] = "root";      // пользователь
$config["mysql"]["password"] = "root";  // пароль
$config["mysql"]["bd"] = "crud";        // название базы данных
$config["mysql"]["table"] = "vedomost"; // название таблицы
// $config["mysql"]["bd"] = "poll_service";
// $config["mysql"]["table"] = "poll_service";
